var data = [
{'name': 'Test1', 'Order': 'Bowen', 'Time': '2015-11-11'},
{'name': 'Test2', 'Order': 'Bowen', 'Time': '2015-11-11'},
{'name': 'Test3', 'Order': 'Bowen', 'Time': '2015-11-11'},
{'name': 'Test4', 'Order': 'Bowen', 'Time': '2015-11-11'}
]

function get_lab_orders(){
	return data;
}